"""The Trove onboarding wizard: welcome, find the server, sign in.

Trove owns sign-in because plugin.video.jellyfin will not take it from
anywhere else: no plugin URL, builtin or JSON-RPC accepts a server plus a
token or a password. What the add-on does read is its own addon_data, so
the finished session is written there and the add-on starts already
signed in. See resources/lib/handover.py for why that lands, and Trove OS
planning/04-jellyfin-onboarding.md for the decision.

What Trove deliberately does NOT own: library choice, playback mode and
the first sync. A whitelist written before the add-on has filled its own
`view` table resolves to nothing, so those stay the add-on's and reach
Kodi's shared dialogs, which this skin styles.

Each step is an xbmcgui.WindowXML bound to a window file in skin.trove:
Kodi looks for a script window in the active skin before this add-on's
own folder, which is why the layouts live there and get the full design.

The flow is a loop rather than nested modals: each step returns the name
of the next one, so Back is just another return value.
"""
import os
import threading
import uuid

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from . import handover
from . import jellyfin

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")
ADDON_ID = ADDON.getAddonInfo("id")

JELLYFIN_ADDON = "plugin.video.jellyfin"

ACTION_BACK = (9, 10, 92)          # nav back / previous menu / backspace

YESNO_DIALOG = 10100
YESNO_YES = 11
CONFIRM_TIMEOUT = 10
INSTALL_TIMEOUT = 300


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[%s] %s" % (ADDON_ID, message), level)


def S(string_id):
    """Strings this add-on writes into labels from Python.

    xbmc.getLocalizedString only reaches Kodi's own table, and a skin's
    31xxx strings are not addressable from an add-on, so anything Python
    writes into a label comes from this add-on's strings.po.
    """
    return ADDON.getLocalizedString(string_id)


def has_jellyfin():
    return xbmc.getCondVisibility("System.HasAddon(%s)" % JELLYFIN_ADDON)


def device_id():
    """A stable id for this box, kept in this add-on's own addon_data.

    Not a setting: Kodi only stores settings declared in a
    resources/settings.xml, which this add-on does not have, so
    setSetting was silently dropped and every run minted a fresh id.
    handover.write() copies whatever comes back here into jellyfin_guid,
    which is the id the token was issued to -- so a new one each time
    registered a new device and a new session in Jellyfin's dashboard on
    every run, the exact opposite of the point.
    """
    directory = xbmcvfs.translatePath(
        "special://profile/addon_data/%s/" % ADDON_ID)
    path = os.path.join(directory, "device_id")
    try:
        with open(path) as handle:
            stored = handle.read().strip()
        if stored:
            return stored
    except (IOError, OSError):
        pass
    stored = str(uuid.uuid4())
    try:
        if not os.path.isdir(directory):
            os.makedirs(directory)
        with open(path, "w") as handle:
            handle.write(stored)
    except (IOError, OSError) as err:
        # Worth carrying on with: a one-off id still signs the box in, it
        # just shows up as another device on the server.
        log("could not store the device id: %s" % err, xbmc.LOGWARNING)
    return stored


class Context(object):
    """What the steps hand each other."""

    def __init__(self):
        self.client = None
        self.server_name = ""
        self.server_address = ""
        self.signed_in = False


# ===================================================================== base
class Step(xbmcgui.WindowXML):
    """A wizard window. Subclasses set `next_step` before closing."""

    def __new__(cls, xml, ctx):
        return super(Step, cls).__new__(cls, xml, ADDON_PATH, "default", "1080i")

    def __init__(self, xml, ctx):
        super(Step, self).__init__()
        self.ctx = ctx
        self.next_step = None
        self.back_step = None

    def onAction(self, action):
        if action.getId() in ACTION_BACK:
            self.next_step = self.back_step
            self.close()

    def set_label(self, control_id, text):
        try:
            self.getControl(control_id).setLabel(text)
        except Exception as err:
            log("setLabel(%s) failed: %s" % (control_id, err), xbmc.LOGWARNING)

    def go(self, step):
        self.next_step = step
        self.close()


# ================================================================== welcome
class Welcome(Step):
    def onInit(self):
        self.back_step = None
        try:
            version = xbmcaddon.Addon(JELLYFIN_ADDON).getAddonInfo("version")
            self.set_label(3010, "%s · %s" % (JELLYFIN_ADDON, version))
        except Exception:
            self.set_label(3010, "%s · %s" % (JELLYFIN_ADDON, S(30010)))

    def onClick(self, control_id):
        if control_id == 3001:
            self.go("connect")
        elif control_id == 3002:
            self.go(None)


# ================================================================== connect
class Connect(Step):
    def onInit(self):
        self.back_step = "welcome"
        self.found = []
        threading.Thread(target=self._discover, daemon=True).start()

    def _discover(self):
        servers = []
        try:
            servers = jellyfin.discover(3.0)
        except Exception as err:
            log("discovery failed: %s" % err, xbmc.LOGWARNING)
        self.found = servers
        items = []
        for server in servers:
            item = xbmcgui.ListItem(server["name"], server["address"])
            item.setProperty("tag", S(30015))
            item.setProperty("ver", jellyfin.probe_version(server["address"],
                                                           device_id()))
            items.append(item)
        try:
            control = self.getControl(3300)
            control.reset()
            if items:
                control.addItems(items)
            self.set_label(3310, (S(30014) % len(servers)) if servers
                           else S(30013))
            self.setFocusId(3300 if items else 3301)
        except Exception as err:
            log("populate failed: %s" % err, xbmc.LOGWARNING)

    def _use(self, typed):
        address = jellyfin.normalise_url(typed)
        if not address:
            if (typed or "").strip():
                xbmcgui.Dialog().ok(S(30011), "%s\n%s" % (typed, S(30027)))
            return
        client = jellyfin.Client(address, device_id())
        # This runs on the window's callback thread, so nothing on screen
        # responds until the request returns. The busy dialog says as much
        # instead of leaving the row looking dead for the whole timeout.
        # It has to be shut before any error dialog, or that opens behind it.
        xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
        info, failure = None, None
        try:
            info = client.public_info()
        except jellyfin.JellyfinError as err:
            failure = err
        finally:
            xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
        if failure is not None:
            xbmcgui.Dialog().ok(S(30011), "%s\n%s" % (address, failure))
            return
        if not info.get("Id"):
            xbmcgui.Dialog().ok(S(30011), "%s\n%s" % (address, S(30016)))
            return
        self.ctx.client = client
        self.ctx.server_address = address
        self.ctx.server_name = info.get("ServerName") or address
        self.go("signin")

    def onClick(self, control_id):
        if control_id == 3300:
            position = self.getControl(3300).getSelectedPosition()
            if 0 <= position < len(self.found):
                self._use(self.found[position]["address"])
        elif control_id == 3301:
            typed = xbmcgui.Dialog().input(S(30017), "http://")
            if typed:
                self._use(typed)
        elif control_id == 3302:
            self.go("welcome")


# =================================================================== signin
class SignIn(Step):
    """Quick Connect runs from the moment this opens; password is the
    fallback for servers with Quick Connect switched off."""

    def onInit(self):
        self.back_step = "connect"
        self.secret = None
        self.chosen = None
        self.users = []
        self.stop = threading.Event()
        client = self.ctx.client
        if client is None:
            # RunScript(script.trove.onboard,signin) with no server argument
            # lands here. There is nothing to sign in to, and reading off
            # the missing client used to raise straight out of onInit --
            # which left the window drawn but inert, with no thread
            # started and every button doing nothing but Back. Step 1 is
            # what this actually needs.
            log("signin opened with no server; starting at connect",
                xbmc.LOGWARNING)
            self.go("connect")
            return
        self.set_label(3900, "%s %s" % (S(30012), self.ctx.server_name))
        self.set_label(3901, "%s · jellyfin %s"
                       % (self.ctx.server_address.split("://")[-1],
                          client.server_version or "?"))
        self.set_label(3204, self.ctx.server_address)
        threading.Thread(target=self._load_users, daemon=True).start()
        threading.Thread(target=self._quick_connect, daemon=True).start()

    # --------------------------------------------------------- user grid
    def _load_users(self):
        try:
            self.users = self.ctx.client.public_users()
        except Exception as err:
            log("public users failed: %s" % err, xbmc.LOGWARNING)
            self.users = []
        items = []
        for user in self.users:
            item = xbmcgui.ListItem(user["name"])
            item.setProperty("initial", (user["name"][:1] or "?").upper())
            item.setProperty("role", S(30018) if user["admin"] else S(30019))
            items.append(item)
        try:
            control = self.getControl(3100)
            control.reset()
            if items:
                control.addItems(items)
                # The window's defaultcontrol fires while this list is
                # still loading, and Kodi will not focus an empty list, so
                # without this the grid draws populated but unfocused.
                self.setFocusId(3100)
            else:
                # Nothing to choose from, so the field cannot say "choose a
                # user first"; it collects the username too.
                self.set_label(3210, S(30026))
                self.setFocusId(3210)
        except Exception as err:
            log("populate users failed: %s" % err, xbmc.LOGWARNING)

    # ------------------------------------------------------ quick connect
    def _quick_connect(self):
        """Show a code and wait for it to be approved, reissuing on expiry.

        Jellyfin drops a Quick Connect request a few minutes after it is
        issued, and /QuickConnect/Connect then answers 404 -- which on this
        endpoint otherwise reads exactly like "not approved yet". Treating
        it as such left the screen showing a code the server had already
        forgotten, polling for it forever: walk away, come back, approve
        the code on your phone, and nothing would happen. A 404 now issues
        a fresh code into the same label instead.
        """
        client = self.ctx.client
        if not client.quick_connect_enabled():
            self.set_label(3200, "----")
            self.set_label(3203, S(30020))
            return

        monitor = xbmc.Monitor()
        approved = False
        while not approved and not self.stop.is_set():
            try:
                code, self.secret = client.quick_connect_initiate()
            except jellyfin.JellyfinError as err:
                log("quick connect initiate failed: %s" % err, xbmc.LOGWARNING)
                self.set_label(3200, "----")
                self.set_label(3203, str(err))
                return
            self.set_label(3200, code)
            log("quick connect code %s" % code)

            expired = False
            while not expired and not self.stop.is_set():
                if monitor.waitForAbort(2.0):
                    return
                try:
                    approved = client.quick_connect_authenticated(self.secret)
                except jellyfin.JellyfinError as err:
                    if err.status == 404:
                        log("quick connect code %s expired, reissuing" % code)
                        expired = True
                    else:
                        log("quick connect poll: %s" % err, xbmc.LOGWARNING)
                    continue
                if approved:
                    break
        if self.stop.is_set():
            return
        self.setProperty("quickconnect", "approved")
        self.set_label(3203, S(30021))
        try:
            client.authenticate_quick_connect(self.secret)
        except jellyfin.JellyfinError as err:
            self.set_label(3203, str(err))
            return
        self._done()

    # ----------------------------------------------------------- password
    def _password(self):
        if self.chosen is None:
            return
        user = self.users[self.chosen]
        password = xbmcgui.Dialog().input(
            "%s · %s" % (S(30022), user["name"]),
            option=xbmcgui.ALPHANUM_HIDE_INPUT)
        # Kodi's keyboard returns "" both for cancel and for an empty entry.
        # This user is only prompted when the server says they have a
        # password, so "" is a cancel either way.
        if not password:
            return
        self._by_name(user["name"], password)

    def _by_name(self, username, password):
        try:
            self.ctx.client.authenticate_by_name(username, password)
        except jellyfin.JellyfinError as err:
            xbmcgui.Dialog().ok(S(30011), "%s\n%s" % (S(30023), err))
            return
        self._done()

    def _typed_username(self):
        username = xbmcgui.Dialog().input(S(30024))
        if not username:
            return
        password = xbmcgui.Dialog().input(S(30022),
                                          option=xbmcgui.ALPHANUM_HIDE_INPUT)
        self._by_name(username, password or "")

    def _done(self):
        self.ctx.signed_in = True
        self.go(None)

    # -------------------------------------------------------------- input
    def onClick(self, control_id):
        if control_id == 3100:
            position = self.getControl(3100).getSelectedPosition()
            if 0 <= position < len(self.users):
                self.chosen = position
                user = self.users[position]
                self.set_label(3210, "%s · %s" % (S(30022), user["name"]))
                if user["has_password"]:
                    self.setFocusId(3210)
                else:
                    self._by_name(user["name"], "")
        elif control_id == 3101:
            self._typed_username()
        elif control_id == 3210:
            if self.chosen is None:
                self._typed_username()
            else:
                self._password()
        elif control_id == 3211:
            if self.chosen is None:
                self._typed_username()
            else:
                self._password()
        elif control_id == 3201:
            self.go("connect")

    def close(self):
        self.stop.set()
        super(SignIn, self).close()


# ================================================================= hand-off
def install_jellyfin():
    """Install Jellyfin for Kodi, then let it run the rest of setup."""
    monitor = xbmc.Monitor()

    if has_jellyfin():
        log("%s is already installed" % JELLYFIN_ADDON)
        xbmc.executebuiltin(
            "RunPlugin(plugin://%s/?mode=restartservice)" % JELLYFIN_ADDON)
        return True

    log("installing %s" % JELLYFIN_ADDON)
    xbmc.executebuiltin("InstallAddon(%s)" % JELLYFIN_ADDON)

    # Every wizard window is shut by now, so without this the box sits on
    # Home showing nothing at all for up to INSTALL_TIMEOUT. A background
    # bar is the right weight: it says what is happening without taking
    # the screen back off the add-on's own dialogs, which follow.
    progress = xbmcgui.DialogProgressBG()
    progress.create(S(30011), S(30028))
    try:
        for _ in range(CONFIRM_TIMEOUT * 2):
            if xbmc.getCondVisibility("Window.IsActive(yesnodialog)"):
                xbmc.executebuiltin("SendClick(%d,%d)"
                                    % (YESNO_DIALOG, YESNO_YES))
                break
            if monitor.waitForAbort(0.5):
                return False

        for second in range(INSTALL_TIMEOUT):
            if has_jellyfin():
                log("%s installed" % JELLYFIN_ADDON)
                return True
            progress.update(int(second * 100 / INSTALL_TIMEOUT))
            if monitor.waitForAbort(1):
                return False
    finally:
        progress.close()

    log("%s was not installed within %d s" % (JELLYFIN_ADDON, INSTALL_TIMEOUT),
        xbmc.LOGERROR)
    xbmcgui.Dialog().ok(S(30011), S(30025))
    return False


# ===================================================================== flow
STEPS = {
    "welcome": (Welcome, "script-trove-onboard-welcome.xml"),
    "connect": (Connect, "script-trove-onboard-connect.xml"),
    "signin": (SignIn, "script-trove-onboard-signin.xml"),
}


def run(start="welcome", server=None):
    """`server` skips discovery and goes straight to that address, which is
    how Settings re-runs a single step."""
    ctx = Context()
    if server:
        ctx.server_address = jellyfin.normalise_url(server)
        ctx.client = jellyfin.Client(ctx.server_address, device_id())
        try:
            info = ctx.client.public_info()
            ctx.server_name = info.get("ServerName") or ctx.server_address
        except jellyfin.JellyfinError:
            ctx.server_name = ctx.server_address

    step = start
    seen = 0
    while step and seen < 64:
        seen += 1
        cls, xml = STEPS[step]
        window = cls(xml, ctx)
        try:
            window.doModal()
            step = window.next_step
        finally:
            del window

    # Written before the add-on is installed, on purpose: its service opens
    # its own server and sign-in dialogs a few seconds after it starts, and
    # finding a valid session on disk is what stops it asking.
    if ctx.signed_in and handover.write(ctx.client):
        install_jellyfin()
    log("wizard finished")
