"""Minimal Jellyfin client for the Trove onboarding wizard.

Only what the wizard needs: find servers, sign in (Quick Connect first,
username as the fallback), list the user's libraries and size them. Uses
urllib so the add-on carries no dependencies.

Checked against Jellyfin 10.11.11.
"""
import json
import socket
import time
import ssl
import urllib.error
import urllib.parse
import urllib.request

DISCOVERY_PORT = 7359
DISCOVERY_MESSAGE = b"who is JellyfinServer?"

CLIENT_NAME = "Trove"
CLIENT_VERSION = "0.1.0"


class JellyfinError(Exception):
    """`status` is the HTTP code when the server answered with one.

    Callers need it to tell apart answers that mean different things on
    the same endpoint: /QuickConnect/Connect returns 404 for a request
    the server has expired, which otherwise reads exactly like "not
    approved yet".
    """

    def __init__(self, message, status=None):
        super(JellyfinError, self).__init__(message)
        self.status = status


def discover(timeout=2.5, device_name="Trove"):
    """Broadcast on udp/7359 and collect whatever answers.

    Returns [{name, address, id}]. Discovery is a broadcast, so it does not
    cross subnets or VLANs, and a host firewall that has no rule for the
    Kodi process will drop the reply -- the server answers to a unicast
    address the sender never registered an outbound mapping for. Callers
    must always offer manual entry as well.
    """
    servers = {}
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    try:
        sock.sendto(DISCOVERY_MESSAGE, ("255.255.255.255", DISCOVERY_PORT))
        deadline = time.time() + timeout
        while True:
            remaining = deadline - time.time()
            if remaining <= 0:
                break
            sock.settimeout(remaining)
            try:
                data, addr = sock.recvfrom(4096)
            except socket.timeout:
                break                 # the collection window closed
            except OSError:
                # Some other host on the subnet answered the broadcast with
                # an ICMP port-unreachable, which surfaces here as
                # ConnectionReset/Refused on the next recvfrom. It says
                # nothing about the servers that have not replied yet, so
                # keep listening until the deadline. socket.timeout is an
                # OSError subclass, so it has to be caught above this.
                continue
            try:
                payload = json.loads(data.decode("utf-8", "replace"))
            except ValueError:
                continue
            if not isinstance(payload, dict) or "Id" not in payload:
                continue          # our own broadcast, echoed back
            address = payload.get("Address") or ("http://%s:8096" % addr[0])
            servers[payload["Id"]] = {
                "name": payload.get("Name") or addr[0],
                "address": address,
                "id": payload["Id"],
            }
    finally:
        sock.close()
    return list(servers.values())


def probe_version(address, device_id, timeout=3):
    """The server's version, for the picker row. "" if it will not say.

    discover() carries only what the UDP reply holds, and that has no
    version in it, so the version column the design puts on each row
    needs one small call per server found. Callers run this off the UI
    thread; a server that does not answer just shows nothing there.
    """
    try:
        info = Client(address, device_id).call("/System/Info/Public",
                                               timeout=timeout) or {}
    except JellyfinError:
        return ""
    return info.get("Version") or ""


def normalise_url(text):
    """Accept 'host', 'host:8096' or a full URL and return a base URL.

    Returns "" for anything unusable, so callers can say so rather than
    reach for an address that cannot work.

    8096 is only ever assumed for a bare http host. Jellyfin behind a
    reverse proxy on a subpath is the ordinary nginx setup, and that proxy
    answers on 80, so a typed path is taken as a complete address and left
    alone. Appending to the whole string, as this used to, turned
    http://media.lan/jellyfin into http://media.lan/jellyfin:8096 -- an
    address that can never resolve, typed by someone with no other way in.

    A non-numeric port makes SplitResult.port raise, which is caught here:
    it used to come out of a click handler, where it killed the callback
    and left the button doing nothing at all.
    """
    text = (text or "").strip().rstrip("/")
    if not text:
        return ""
    if "://" not in text:
        text = "http://" + text
    parts = urllib.parse.urlsplit(text)
    if parts.scheme not in ("http", "https"):
        return ""
    try:
        port = parts.port
    except ValueError:
        return ""
    if not parts.hostname:
        return ""
    netloc = parts.netloc
    if not port and parts.scheme == "http" and not parts.path:
        netloc += ":8096"
    return urllib.parse.urlunsplit((parts.scheme, netloc, parts.path, "", ""))


class Client(object):
    def __init__(self, base_url, device_id, device_name="Trove"):
        self.base_url = base_url.rstrip("/")
        self.device_id = device_id
        self.device_name = device_name
        self.token = None
        self.user_id = None
        self.user_name = None
        self.server_id = None
        self.server_name = None
        self.server_version = None

    # ---------------------------------------------------------------- http
    def _auth_header(self):
        header = ('MediaBrowser Client="%s", Device="%s", DeviceId="%s", Version="%s"'
                  % (CLIENT_NAME, self.device_name, self.device_id, CLIENT_VERSION))
        if self.token:
            header += ', Token="%s"' % self.token
        return header

    def call(self, path, method="GET", body=None, timeout=8):
        data = json.dumps(body).encode("utf-8") if body is not None else None
        request = urllib.request.Request(self.base_url + path, data=data, method=method)
        request.add_header("Authorization", self._auth_header())
        request.add_header("Content-Type", "application/json")
        request.add_header("Accept", "application/json")
        context = ssl._create_unverified_context() if self.base_url.startswith("https") else None
        try:
            opener = urllib.request.urlopen(request, timeout=timeout, context=context)
        except urllib.error.HTTPError as err:
            raise JellyfinError("%s %s" % (err.code, path), status=err.code)
        except Exception as err:
            raise JellyfinError(str(err))
        with opener as response:
            raw = response.read().decode("utf-8", "replace")
        return json.loads(raw) if raw.strip() else None

    # ------------------------------------------------------------- server
    def public_info(self):
        info = self.call("/System/Info/Public") or {}
        self.server_id = info.get("Id")
        self.server_name = info.get("ServerName")
        self.server_version = info.get("Version")
        return info

    def public_users(self):
        """The users the server is willing to name on a login screen.

        A server with "hide users from login screen" set returns an empty
        list, which is not an error: sign-in then has to be Quick Connect
        or a typed username. The design's user grid is simply empty.
        """
        try:
            users = self.call("/Users/Public") or []
        except JellyfinError:
            return []
        out = []
        for user in users:
            policy = user.get("Policy") or {}
            out.append({
                "id": user.get("Id"),
                "name": user.get("Name") or "",
                "admin": bool(policy.get("IsAdministrator")),
                "has_password": bool(user.get("HasPassword")),
            })
        return out

    # ------------------------------------------------------ quick connect
    def quick_connect_enabled(self):
        try:
            return bool(self.call("/QuickConnect/Enabled"))
        except JellyfinError:
            return False

    def quick_connect_initiate(self):
        """Returns (code, secret). 10.9+ wants POST; older builds used GET."""
        try:
            state = self.call("/QuickConnect/Initiate", "POST")
        except JellyfinError:
            state = self.call("/QuickConnect/Initiate", "GET")
        if not state or not state.get("Secret"):
            raise JellyfinError("no quick connect secret")
        return state.get("Code"), state.get("Secret")

    def quick_connect_authenticated(self, secret):
        state = self.call("/QuickConnect/Connect?secret=" + urllib.parse.quote(secret))
        return bool(state and state.get("Authenticated"))

    def authenticate_quick_connect(self, secret):
        result = self.call("/Users/AuthenticateWithQuickConnect", "POST", {"Secret": secret})
        return self._store_auth(result)

    # ----------------------------------------------------------- password
    def authenticate_by_name(self, username, password):
        result = self.call("/Users/AuthenticateByName", "POST",
                           {"Username": username, "Pw": password or ""})
        return self._store_auth(result)

    def _store_auth(self, result):
        if not result or not result.get("AccessToken"):
            raise JellyfinError("no access token")
        self.token = result["AccessToken"]
        user = result.get("User") or {}
        self.user_id = user.get("Id")
        self.user_name = user.get("Name")
        return self.user_name

    # ---------------------------------------------------------- libraries
    def views(self):
        """The user's libraries, as the Jellyfin app lists them."""
        if not self.user_id:
            raise JellyfinError("not signed in")
        data = self.call("/Users/%s/Views" % self.user_id) or {}
        out = []
        for item in data.get("Items", []):
            out.append({
                "id": item.get("Id"),
                "name": item.get("Name"),
                "type": (item.get("CollectionType") or "mixed").upper(),
            })
        return out

    def count_items(self, parent_id):
        """TotalRecordCount for a library, without pulling the items."""
        query = urllib.parse.urlencode({
            "ParentId": parent_id, "Recursive": "true", "Limit": "0",
            "IncludeItemTypes": "Movie,Series,Episode,Audio,Video",
        })
        data = self.call("/Users/%s/Items?%s" % (self.user_id, query)) or {}
        return int(data.get("TotalRecordCount") or 0)
