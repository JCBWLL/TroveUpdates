"""Hand a finished sign-in to plugin.video.jellyfin.

The add-on takes no credentials through any entry point -- no plugin URL,
builtin or JSON-RPC accepts a server plus a token. The only lever from
outside is the state it reads off disk at startup, so that is what this
writes: `data.json` and `jellyfin_guid` in its addon_data directory.

Read out of plugin.video.jellyfin 2.2.0. The path to a signed-in start is:

    Connect.register()
      -> connection_manager.connect()
           get_available_servers()      sorts Servers[] by DateLastAccessed
           connect_to_server(first)     GET system/info/public must answer
             _after_connect_validated()
               validate_authentication_token()   GET system/info with Token
               -> State = SignedIn  when AccessToken survives that call

`register()` returns on SignedIn *before* the branch that would open the
server picker, so a valid entry here skips both the server and sign-in
dialogs. Anything less -- a stale token, an unreachable address, a missing
Id -- just drops through to the add-on's own dialogs, which Trove also
draws. There is no state where this leaves someone stranded.

`Id` must be the server's own GUID from /System/Info/Public:
`Credentials.add_update_server` raises if it is null.

Deliberately NOT written here: `server`, `serverName` and the library
whitelist. register() sets the first two itself on a successful connect,
and a whitelist written before the add-on has filled its own `view` table
resolves to nothing (see planning/04, hard limit 2). Library choice stays
the add-on's.
"""
import json
import os
import time

import xbmc
import xbmcvfs

ADDON_DATA = "special://profile/addon_data/plugin.video.jellyfin/"

# The add-on's own format, from connection_manager: datetime.now() through
# "%Y-%m-%dT%H:%M:%SZ". The Z is a lie -- it writes local time -- but it has
# to be matched exactly, see _stamp().
STAMP = "%Y-%m-%dT%H:%M:%SZ"


def _stamp(others):
    """A DateLastAccessed that sorts ahead of every server already listed.

    get_available_servers() sorts Servers[] by this field as a plain
    string, descending, and connect() takes the first. The add-on writes
    it as local time, so a UTC stamp loses to any entry the add-on wrote
    itself anywhere east of Greenwich: the box would come up signed in to
    the server it already knew instead of the one just set up. Writing
    local time matches it; stepping past the highest stamp covers a clock
    that has since gone backwards, which would do the same thing.
    """
    now = time.strftime(STAMP, time.localtime())
    highest = max([s.get("DateLastAccessed") or "" for s in others] or [""])
    if now > highest:
        return now
    try:
        later = time.mktime(time.strptime(highest, STAMP)) + 1
    except (ValueError, OverflowError):
        return now
    return time.strftime(STAMP, time.localtime(later))


def _directory():
    path = xbmcvfs.translatePath(ADDON_DATA)
    if not os.path.isdir(path):
        os.makedirs(path)
    return path


def write(client):
    """Write the signed-in session. Returns True if it landed."""
    if not (client.server_id and client.token and client.user_id):
        xbmc.log("[script.trove.onboard] incomplete session, not writing",
                 xbmc.LOGWARNING)
        return False

    directory = _directory()

    # The device id the token was issued to. Keeping it means Jellyfin's
    # dashboard shows one device, not one per sign-in.
    with open(os.path.join(directory, "jellyfin_guid"), "w") as handle:
        handle.write(client.device_id)

    path = os.path.join(directory, "data.json")
    # Merge rather than replace: a box that already knows another server
    # should keep it, just not ahead of this one.
    try:
        with open(path, "rb") as handle:
            credentials = json.load(handle)
    except (IOError, OSError, ValueError):
        credentials = {}
    others = [s for s in credentials.get("Servers", [])
              if s.get("Id") != client.server_id]

    server = {
        "Id": client.server_id,
        "Name": client.server_name or client.base_url,
        "address": client.base_url,
        "AccessToken": client.token,
        "UserId": client.user_id,
        "DateLastAccessed": _stamp(others),
        "Users": [{"Id": client.user_id, "IsSignedInOffline": True}],
    }
    # List order is cosmetic -- the add-on sorts on DateLastAccessed -- but
    # it keeps the file readable in the order it will actually be used.
    credentials["Servers"] = [server] + others

    with open(path, "w") as handle:
        json.dump(credentials, handle, sort_keys=True, indent=4)

    xbmc.log("[script.trove.onboard] wrote credentials for %s (%s)"
             % (server["Name"], server["Id"]), xbmc.LOGINFO)
    return True


def already_signed_in():
    """True when data.json already carries a token for some server."""
    try:
        path = os.path.join(xbmcvfs.translatePath(ADDON_DATA), "data.json")
        with open(path, "rb") as handle:
            credentials = json.load(handle)
    except (IOError, OSError, ValueError):
        return False
    return any(s.get("AccessToken") for s in credentials.get("Servers", []))
