"""Entry point for the Trove Jellyfin onboarding wizard.

    RunScript(script.trove.onboard)                      the whole flow
    RunScript(script.trove.onboard,<step>)               one step
    RunScript(script.trove.onboard,<step>,<server-url>)  skip discovery

The steps are `welcome`, `connect` and `signin`, which is everything
Trove owns. Library choice, playback mode and the first sync belong to
plugin.video.jellyfin, which this hands off to once it has a session.
Settings › Jellyfin re-runs the whole flow.
"""
import sys

from resources.lib import wizard


def main():
    args = [a for a in sys.argv[1:] if a]
    start = args[0] if args and args[0] in wizard.STEPS else "welcome"
    server = args[1] if len(args) > 1 else None
    wizard.run(start, server)


if __name__ == "__main__":
    main()
