"""Entry point for Trove's in-player tools.

    RunScript(script.trove.player,episodes)   the episode switcher

Opened from the Episodes button on the player OSD, which only appears
while an episode is playing.
"""
import sys

from resources.lib import episodes


def main():
    args = [a for a in sys.argv[1:] if a]
    action = args[0] if args else "episodes"
    if action == "episodes":
        episodes.open_switcher()


if __name__ == "__main__":
    main()
