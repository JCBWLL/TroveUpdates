"""The in-player episode switcher: the rest of the series, over the video.

Everything here reads Kodi's own library. `plugin.video.jellyfin` syncs
into it, so a Jellyfin episode has a real videodb row and a real
`tvshowid` -- which is the whole reason this works without touching
Jellyfin's API.

It lives in an add-on rather than the skin because the skin cannot get
from the playing item to its show. Kodi exposes the episode's own DBID
and nothing for the show it belongs to, so a `videodb://tvshows/...`
path cannot be built in XML. The window layout still lives in
skin.trove: Kodi loads a script window from the active skin before this
add-on's own copy, the same split the onboarding wizard uses.
"""
import json

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")
ADDON_ID = ADDON.getAddonInfo("id")

WINDOW_XML = "script-trove-episodes.xml"

HEADING = 9010          # "<show> · S1E4"
SEASONS = 9100          # season tabs
CARDS = 9200            # the episode rail

ACTION_BACK = (9, 10, 92)


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[%s] %s" % (ADDON_ID, message), level)


def S(string_id):
    """Strings this add-on writes into labels from Python.

    A skin's 31xxx strings are not addressable from an add-on, so
    anything Python puts in a label comes from this add-on's strings.po.
    """
    return ADDON.getLocalizedString(string_id)


def rpc(method, params=None):
    payload = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        payload["params"] = params
    try:
        answer = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
    except ValueError as err:
        log("%s: unreadable answer (%s)" % (method, err), xbmc.LOGWARNING)
        return None
    if "error" in answer:
        log("%s: %s" % (method, answer["error"]), xbmc.LOGWARNING)
        return None
    return answer.get("result")


# ------------------------------------------------------------------ library
def playing_episode():
    """The episode on screen, or None if this box has nothing to switch.

    Anything played from outside the library -- a file, a plugin path, a
    stream -- comes back with `tvshowid` -1, and there is no series to
    list. The caller says so rather than opening an empty drawer.
    """
    players = rpc("Player.GetActivePlayers") or []
    video = next((p for p in players if p.get("type") == "video"), None)
    if not video:
        return None
    result = rpc("Player.GetItem", {
        "playerid": video["playerid"],
        "properties": ["tvshowid", "season", "episode", "showtitle", "title"],
    }) or {}
    item = result.get("item") or {}
    if item.get("type") != "episode":
        return None
    try:
        if int(item.get("tvshowid", -1)) < 1:
            return None
    except (TypeError, ValueError):
        return None
    return item


def series_episodes(tvshowid):
    """Every episode of the show, specials included, in running order."""
    result = rpc("VideoLibrary.GetEpisodes", {
        "tvshowid": int(tvshowid),
        "properties": ["title", "season", "episode", "runtime", "playcount",
                       "resume", "art"],
        "sort": {"method": "episode", "order": "ascending"},
    }) or {}
    return result.get("episodes") or []


def _int(value, fallback=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return fallback


def _runtime(seconds):
    minutes = int(round(_int(seconds) / 60.0))
    return (S(30003) % minutes) if minutes else ""


def _percent(episode):
    """How far in this episode was left, 0-100.

    `resume.total` is what the player actually measured; `runtime` is the
    scraper's guess and can disagree by minutes, so the stored total wins
    when there is one.
    """
    resume = episode.get("resume") or {}
    total = _int(resume.get("total")) or _int(episode.get("runtime"))
    position = _int(resume.get("position"))
    if total <= 0 or position <= 0:
        return 0
    return max(0, min(100, int(position * 100 / total)))


def _card(episode, playing_id):
    art = episode.get("art") or {}
    item = xbmcgui.ListItem(episode.get("title") or "")
    item.setArt({"thumb": art.get("thumb") or ""})
    item.setProperties({
        "episodeid": str(_int(episode.get("episodeid"))),
        "no": S(30004) % _int(episode.get("episode")),
        "dur": _runtime(episode.get("runtime")),
        "pct": str(_percent(episode)),
        "playing": "true" if _int(episode.get("episodeid")) == playing_id else "",
        "watched": "true" if _int(episode.get("playcount")) > 0 else "",
    })
    return item


# ------------------------------------------------------------------- window
class Switcher(xbmcgui.WindowXMLDialog):
    """A dialog, not a window: a window would take the screen off the
    video and stop fullscreen playback. The OSD stays underneath."""

    def __new__(cls, current, episodes):
        return super(Switcher, cls).__new__(
            cls, WINDOW_XML, ADDON_PATH, "default", "1080i")

    def __init__(self, current, episodes):
        super(Switcher, self).__init__()
        self.current = current
        self.episodes = episodes
        self.playing_id = _int(current.get("id"), -1)
        self.seasons = sorted({_int(e.get("season")) for e in episodes})
        self.season = _int(current.get("season"),
                           self.seasons[0] if self.seasons else 0)
        if self.season not in self.seasons and self.seasons:
            self.season = self.seasons[0]
        self.shown = []

    # ------------------------------------------------------------ populate
    def onInit(self):
        show = self.current.get("showtitle") or ""
        self.set_label(HEADING, "%s · %s" % (
            show, S(30005) % (_int(self.current.get("season")),
                              _int(self.current.get("episode")))))
        self._fill_seasons()
        self._fill_cards(focus_playing=True)

    def _fill_seasons(self):
        items = []
        for season in self.seasons:
            count = sum(1 for e in self.episodes
                        if _int(e.get("season")) == season)
            item = xbmcgui.ListItem(
                S(30002) if season == 0 else S(30001) % season)
            item.setProperties({
                "season": str(season),
                "count": str(count),
                "on": "true" if season == self.season else "",
            })
            items.append(item)
        try:
            control = self.getControl(SEASONS)
            control.reset()
            control.addItems(items)
        except Exception as err:
            log("season tabs failed: %s" % err, xbmc.LOGWARNING)

    def _fill_cards(self, focus_playing=False):
        self.shown = [e for e in self.episodes
                      if _int(e.get("season")) == self.season]
        items = [_card(e, self.playing_id) for e in self.shown]
        try:
            control = self.getControl(CARDS)
            control.reset()
            if not items:
                return
            control.addItems(items)
            # Kodi will not focus a list while it is empty, so this has to
            # come after addItems, not from the window's defaultcontrol.
            self.setFocusId(CARDS)
            if focus_playing:
                for index, episode in enumerate(self.shown):
                    if _int(episode.get("episodeid")) == self.playing_id:
                        control.selectItem(index)
                        break
        except Exception as err:
            log("episode rail failed: %s" % err, xbmc.LOGWARNING)

    def set_label(self, control_id, text):
        try:
            self.getControl(control_id).setLabel(text)
        except Exception as err:
            log("setLabel(%s) failed: %s" % (control_id, err), xbmc.LOGWARNING)

    # --------------------------------------------------------------- input
    def onClick(self, control_id):
        if control_id == SEASONS:
            position = self.getControl(SEASONS).getSelectedPosition()
            if 0 <= position < len(self.seasons):
                self.season = self.seasons[position]
                self._fill_seasons()
                self._fill_cards()
        elif control_id == CARDS:
            position = self.getControl(CARDS).getSelectedPosition()
            if 0 <= position < len(self.shown):
                self._play(position)

    def onAction(self, action):
        if action.getId() in ACTION_BACK:
            self.close()

    def _play(self, position):
        """Start this episode, the way picking one in a season view does.

        `resume` is passed explicitly because a JSON-RPC open never shows
        Kodi's resume prompt: without it a part-watched episode silently
        restarts from zero.

        This deliberately opens one episode rather than queueing the rest
        of the season behind it. Queueing reads better on paper -- it is
        what keeps "play the next episode" alive -- but a library synced
        by Jellyfin for Kodi in add-on mode is full of
        plugin://plugin.video.jellyfin/...?mode=play paths, and Kodi will
        not play those from a playlist: it pre-resolves the queue and
        drops every one as "skipping unplayable item". Opening a single
        episodeid lets the add-on resolve it at play time, which is the
        only path that works for a plugin-backed library. Verified
        against a PlexKodiConnect library, which has the same shape.
        """
        episode = self.shown[position]
        rpc("Player.Open",
            {"item": {"episodeid": _int(episode.get("episodeid"))},
             "options": {"resume": True}})
        self.close()


# ----------------------------------------------------------------- entry
def open_switcher():
    current = playing_episode()
    if not current:
        log("nothing switchable is playing")
        xbmcgui.Dialog().notification(S(30000), S(30006),
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        return
    episodes = series_episodes(current["tvshowid"])
    if not episodes:
        log("no episodes for tvshowid %s" % current["tvshowid"],
            xbmc.LOGWARNING)
        xbmcgui.Dialog().notification(S(30000), S(30006),
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        return
    window = Switcher(current, episodes)
    try:
        window.doModal()
    finally:
        del window
