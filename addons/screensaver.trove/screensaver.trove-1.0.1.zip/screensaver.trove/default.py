"""Trove idle screensaver.

Kodi has no way for a skin to supply a screensaver, so the design's idle
screen ships as this companion add-on. It borrows the active skin's fonts
and colours, which is why it is meant to run with skin.trove.
"""
import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
CWD = ADDON.getAddonInfo("path")


class TroveIdle(xbmcgui.WindowXMLDialog):
    """Closes on any input, as a screensaver must."""

    def onAction(self, action):
        self.close()

    def onClick(self, controlId):
        self.close()

    def onFocus(self, controlId):
        pass


def run():
    window = TroveIdle("script-trove-idle.xml", CWD, "default")
    try:
        window.doModal()
    finally:
        del window


if __name__ == "__main__":
    run()
